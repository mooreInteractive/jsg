<?php session_start(); $_SESSION['score'] += 1; ?>
